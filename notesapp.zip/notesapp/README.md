Ohjelma näyttää käyttäjän kurssit listassa ja sisältää toiminnallisuuden lisätä omavalintainen kurssi listaan.

Projekti käynnistyy kehitys-modessa suorittamalla komennon "npm run dev"
Riippuvuudet asentuvat "npm install" komennolla
