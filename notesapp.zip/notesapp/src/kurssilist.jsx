import SaveFeatures from "./SaveFeatures";
import KurssiTiedot from "./KurssiTiedot";


const KurssiList = ({ kurssi, addNewKurssi }) => {
  if (kurssi.length === 0) {
    return <p>Ei kursseja.</p>;
  }
  return (
    <div>
      <SaveFeatures addNewKurssi={addNewKurssi} />
      <ul>
        {kurssi.map((p, i) => {
          return (
            <KurssiTiedot
              key={i}
              name={p.name}
              bgcolor={p.color}
            />
          );
        })}
      </ul>
    </div>
  );
};

export default KurssiList;
