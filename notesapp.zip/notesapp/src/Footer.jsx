const Footer = () => {
  return (
    <div>
      <input
        type="text"
        name="name"
        placeholder="Lisää muistiinpano"
      />
      <button>Lisää muistiinpano</button>
    </div>
  );
};

export default Footer;
