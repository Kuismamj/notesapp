const KurssiTiedot = ({ name,bgcolor="#0000FF"}) => {
  return (
    <li style={{ background: bgcolor }}>
      {name}
    </li>
  );
};

export default KurssiTiedot;
