import { useState } from "react";

const SaveFeatures = ({ addNewKurssi }) => {
  const [name, setName] = useState("");
  

  const handleSave = (e) => {
    if (name === "") {
      return;
    }
    let newKurssi = { name};
    addNewKurssi(newKurssi);
    setName("");
    
  };
  return (
    <div>
      <input
        type="text"
        name="name"
        placeholder="Lisää kurssin nimi"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={handleSave}>Lisää kurssi</button>
    </div>
  );
};

export default SaveFeatures;
