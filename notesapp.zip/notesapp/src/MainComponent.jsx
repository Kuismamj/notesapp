import { useEffect } from "react";
import { useState } from "react";
import KurssiList from "./KurssiList";

const MainComponent = () => {
  const [kurssi, setkurssi] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await fetch(
        "https://luentomuistiinpano-api.deta.dev/courses/"
      );
      let json = await data.json();
      
      setkurssi(json);
      
    };
    fetchData();
  }, []);

  const addNewKurssi = (p) => {
    setkurssi([...kurssi, p]);
  };
  return (
    <div>
      <KurssiList kurssi={kurssi} addNewKurssi={addNewKurssi} />
    </div>
  );
};

export default MainComponent;
