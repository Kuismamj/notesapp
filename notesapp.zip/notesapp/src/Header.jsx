const Header = () => {
  return <h1>NOTESAPP</h1>;
  
};


export default Header;
